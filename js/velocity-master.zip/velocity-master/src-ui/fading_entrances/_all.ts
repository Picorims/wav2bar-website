/*
 * velocity-animate (C) 2014-2018 Julian Shapiro.
 *
 * Licensed under the MIT license. See LICENSE file in the project root for details.
 */

import "./fadeIn";
import "./fadeInDown";
import "./fadeInDownBig";
import "./fadeInLeft";
import "./fadeInLeftBig";
import "./fadeInRight";
import "./fadeInRightBig";
import "./fadeInUp";
import "./fadeInUpBig";
